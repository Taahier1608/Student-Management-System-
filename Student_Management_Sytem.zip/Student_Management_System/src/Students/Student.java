package Students;

import java.sql.*;

public class Student {
    public static void Login() {
        try (
            Connection connection = DatabaseManager.getConnection();
            Statement statement = connection.createStatement();
        ) {
            for (char classLetter = 'A'; classLetter <= 'E'; classLetter++) {
                String tableName = "Class_" + classLetter;
                System.out.println("Displaying data from table: " + tableName);
                displayDataFromTable(statement, tableName);
                System.out.println();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void displayDataFromTable(Statement statement, String tableName) throws SQLException {
        String sqlQuery = "SELECT * FROM " + tableName;
        ResultSet resultSet = statement.executeQuery(sqlQuery);

        System.out.println("Roll Number\t\tName\t\tAge\t\tMarks\t\tGrade\t\tCity");
	    while (resultSet.next()) {
	        int rollNum = resultSet.getInt("Roll_Num");
	        String name = resultSet.getString("Name");
	        int age = resultSet.getInt("Age");
	        double marks = resultSet.getDouble("Marks");
	        String grade = resultSet.getString("Grade");
	        String city = resultSet.getString("City");
	        
	        System.out.println(rollNum + "\t\t" + name + "\t\t" + age + "\t\t" + marks + "\t\t" + grade + "\t\t" + city);
        }
    }
}
  