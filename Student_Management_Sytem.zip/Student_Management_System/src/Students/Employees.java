package Students;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class Employees {

	public static void login() {
        boolean loggedIn = false;
        Scanner scanner = new Scanner(System.in);
        while (!loggedIn) {
            // Prompt user for ID and password
            System.out.print("Enter your ID: ");
            int id = scanner.nextInt();
            System.out.print("Enter your password: ");
            String password = scanner.next();

            // Check if the entered ID and password match any record in the database
            try (
                Connection connection = DatabaseManager.getConnection();
                PreparedStatement statement = connection.prepareStatement("SELECT * FROM Employees WHERE employee_id = ? AND password = ?");
            ) {
                statement.setInt(1, id);
                statement.setString(2, password);
                ResultSet resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    System.out.println("Employee login successful");
                    loggedIn = true;
                    // Display data of Student_Classes table and prompt to select a class ID
                    displayStudentClassesAndSelectClass(connection, scanner);
                } else {
                    System.out.println("Invalid ID or password. Please try again.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static void displayStudentClassesAndSelectClass(Connection connection, Scanner scanner) {
        try (
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM Student_Classes");
        ) {
            System.out.println("\nData of Student_Classes:");
            while (resultSet.next()) {
                int classId = resultSet.getInt("class_id");
                String className = resultSet.getString("class_name");
                System.out.println("Class ID: " + classId + ", Class Name: " + className);
            }

            // Prompt user to select a class ID
            System.out.print("Enter the Class ID to view details: ");
            int selectedClassId = scanner.nextInt();
            System.out.println("Selected Class ID: " + selectedClassId);
            ClassData.displayClassData(selectedClassId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

