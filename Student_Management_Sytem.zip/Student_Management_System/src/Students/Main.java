package Students;
import java.util.Scanner;
import java.sql.*;


// Employee id = 101 , 102 ; Password = 101 , 102



public class Main {
    public static void main(String[] args) {
        // Display message for establishing connection with database
        System.out.println("Establishing connection with database...");

        // Establish connection to the database
        try {
            DatabaseManager.getConnection();
            // Display message for successful connection
            System.out.println("Connection successful with database");
        } catch (SQLException e) {
            System.out.println("Failed to establish connection with database");
            e.printStackTrace();
            return; // Exit the program if connection fails
        }

        // Display college name
        System.out.println("COLLEGE NAME");

        // Display login options
        System.out.println("Login as:");
        System.out.println("1. Employee");
        System.out.println("2. Student");
        System.out.println("3. Exit");

        // Prompt user for choice
        Scanner scanner = new Scanner(System.in);
        int choice;
        boolean employeeLoggedIn = false;
        do {
            if (!employeeLoggedIn) {
                System.out.print("Enter your choice: ");
                choice = scanner.nextInt();
            } else {
                // Skip prompting for choice if employee is already logged in
                choice = 0;
            }

            switch (choice) {
                case 1:
                    // Employee login selected
                    Employees.login();
                    employeeLoggedIn = true;
                    break;
                case 2:
                    // Student login selected
                    Student.Login();
                    break;
                case 3:
                    // Exit the system
                    System.out.println("Exiting the system...");
                    break;
                default:
                    if (!employeeLoggedIn) {
                        // Invalid choice, prompt again
                        System.out.println("Invalid choice. Please enter a valid option.");
                    }
            }
        } while (choice != 3);

        // Close scanner
        scanner.close();

        // Close connection to the database
       
    }
}


