package Students;

import java.sql.*;
import java.util.Scanner;

public class UpdateData {
    public static void updateData() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("1. Go Back : ");
      
        
        System.out.print("2. Enter Roll Number to update data : ");
        int rollNumber = scanner.nextInt();
        System.out.print("3. Enter Class_Id to update data : ");
        int classId= scanner.nextInt();
        
        displayData(rollNumber,classId);

        // Display choice menu
        System.out.println("\nSelect an attribute to update :");
        System.out.println("1. Update marks");
        System.out.println("2. Update age");
        System.out.println("3. Update city");
        System.out.println("4. Go Back : ");
        System.out.println("Enter your Choice : ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                updateMarks(rollNumber,classId);
                break;
            case 2:
                updateAge(rollNumber,classId);
                break;
            case 3:
                updateCity(rollNumber,classId);
                break;
            case 4:
			updateData(); 
            default:
                System.out.println("Invalid choice");
        }
    }

    private static void displayData(int rollNumber, int classId) {
        String tableName = "Class_" + (char) ('A' + classId - 1);
        try (
            Connection connection = DatabaseManager.getConnection();
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM " + tableName + " WHERE Roll_Num = ?");
        ) {
            statement.setInt(1, rollNumber);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                int rollNum = resultSet.getInt("Roll_Num");
                String name = resultSet.getString("Name");
                int age = resultSet.getInt("Age");
                double marks = resultSet.getDouble("Marks");
                String grade = resultSet.getString("Grade");
                String city = resultSet.getString("City");

                System.out.println("\nData for Roll Number " + rollNum + " in " + tableName + ":");
                System.out.println("Name: " + name);
                System.out.println("Age: " + age);
                System.out.println("Marks: " + marks);
                System.out.println("Grade: " + grade);
                System.out.println("City: " + city);
            } else {
                System.out.println("No data found for Roll Number " + rollNumber + " in " + tableName);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    private static void updateMarks(int rollNumber,int classId) {
        // Implement update of marks
    	 Scanner scanner = new Scanner(System.in);
         System.out.print("Enter new marks: ");
         double newMarks = scanner.nextDouble();
         String newGrade = calculateGrade(newMarks); // Calculate grade based on new marks

         String tableName = "Class_" + (char) ('A' + classId - 1);
         try (
             Connection connection = DatabaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement("UPDATE " + tableName + " SET Marks = ?, Grade = ? WHERE Roll_Num = ?");
         ) {
             statement.setDouble(1, newMarks);
             statement.setString(2, newGrade);
             statement.setInt(3, rollNumber);

             int rowsUpdated = statement.executeUpdate();
             if (rowsUpdated > 0) {
                 System.out.println("Marks and grade updated successfully for Roll Number " + rollNumber);
                 System.out.println("New Marks : "+newMarks);
                 System.out.println("New Grade : "+newGrade);
             } else {
                 System.out.println("No rows were updated");
             }
         } catch (SQLException e) {
             e.printStackTrace();
         }    
    }
    private static String calculateGrade(double marks) {
        if (marks < 75.0) {
            return "C";
        } else if (marks >= 75.0 && marks <= 85.0) {
            return "B";
        } else {
            return "A";
        }
    }

    private static void updateAge(int rollNumber,int classId) {
        // Implement update of age
    	Scanner scanner = new Scanner(System.in);
        System.out.print("Enter new age: ");
        int newAge = scanner.nextInt();

        String tableName = "Class_" + (char) ('A' + classId - 1);
        try (
            Connection connection = DatabaseManager.getConnection();
            PreparedStatement statement = connection.prepareStatement("UPDATE " + tableName + " SET Age = ? WHERE Roll_Num = ?");
        ) {
            statement.setInt(1, newAge);
            statement.setInt(2, rollNumber);

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Age updated successfully for Roll Number " + rollNumber);
                System.out.println("Updated Age of Student : "+newAge);
            } else {
                System.out.println("No rows were updated");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    private static void updateCity(int rollNumber,int classId) {
        // Implement update of city
    	Scanner scanner = new Scanner(System.in);
        System.out.print("Enter new city: ");
        String newCity = scanner.nextLine();

        String tableName = "Class_" + (char) ('A' + classId - 1);
        try (
            Connection connection = DatabaseManager.getConnection();
            PreparedStatement statement = connection.prepareStatement("UPDATE " + tableName + " SET City = ? WHERE Roll_Num = ?");
        ) {
            statement.setString(1, newCity);
            statement.setInt(2, rollNumber);

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("City updated successfully for Roll Number " + rollNumber);
                System.out.println("Updated City of Student : "+newCity);
            } else {
                System.out.println("No rows were updated");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
